<?php
/* Smarty version 3.1.39, created on 2021-05-23 11:23:36
  from '/Users/razib/Documents/valet/business-suite/ui/theme/default/marketing_crm/admin/conversion_report.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60aa7378155db4_32209762',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6aeb51a5b73e65f120036fc01357144b82d3ca19' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/default/marketing_crm/admin/conversion_report.tpl',
      1 => 1621766449,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60aa7378155db4_32209762 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['layouts_admin']->value));
}
}
