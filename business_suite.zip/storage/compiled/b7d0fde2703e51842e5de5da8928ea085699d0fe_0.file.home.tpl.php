<?php
/* Smarty version 3.1.39, created on 2021-04-09 09:43:44
  from '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/agency_default/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60705a10c38f78_90488355',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b7d0fde2703e51842e5de5da8928ea085699d0fe' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/agency_default/home.tpl',
      1 => 1617975819,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60705a10c38f78_90488355 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./layout.tpl");
}
}
