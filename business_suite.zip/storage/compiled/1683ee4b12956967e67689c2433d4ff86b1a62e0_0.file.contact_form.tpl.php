<?php
/* Smarty version 3.1.39, created on 2021-05-10 07:40:59
  from '/Users/razib/Documents/valet/business-suite/ui/theme/default/marketing_crm/admin/contact_form.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60991bcb137936_93044126',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1683ee4b12956967e67689c2433d4ff86b1a62e0' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/default/marketing_crm/admin/contact_form.tpl',
      1 => 1620646853,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60991bcb137936_93044126 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row">
    <div class="col-md-6">
        <div class="mb-3">
            <label>First Name</label>
            <input class="form-control" name="first_name">
        </div>
    </div>
    <div class="col-md-6">
        <div class="mb-3">
            <label>Last Name</label>
            <input class="form-control" name="last_name">
        </div>
    </div>
</div>
<?php }
}
