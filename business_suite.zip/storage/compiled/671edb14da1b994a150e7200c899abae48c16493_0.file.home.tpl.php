<?php
/* Smarty version 3.1.39, created on 2021-08-14 11:57:41
  from '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/alpha/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6117e7f5747cc0_17782209',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '671edb14da1b994a150e7200c899abae48c16493' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/alpha/home.tpl',
      1 => 1628956657,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6117e7f5747cc0_17782209 (Smarty_Internal_Template $_smarty_tpl) {
}
}
