<?php
/* Smarty version 3.1.39, created on 2021-09-28 15:05:18
  from '/Users/razib/Documents/valet/business-suite/ui/theme/default/content_only.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6153676e6d4287_70217821',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '503c37a29a9397e3cc3c7662a95e0002e0058af8' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/default/content_only.tpl',
      1 => 1556267287,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../../../".((string)$_smarty_tpl->tpl_vars[\'_pd\']->value)."/views/".((string)$_smarty_tpl->tpl_vars[\'_include\']->value).".tpl' => 1,
  ),
),false)) {
function content_6153676e6d4287_70217821 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../../../".((string)$_smarty_tpl->tpl_vars['_pd']->value)."/views/".((string)$_smarty_tpl->tpl_vars['_include']->value).".tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}
