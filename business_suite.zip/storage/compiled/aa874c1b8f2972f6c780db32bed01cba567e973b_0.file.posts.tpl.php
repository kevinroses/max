<?php
/* Smarty version 3.1.39, created on 2021-03-24 17:54:26
  from '/Users/razib/Documents/valet/business-suite/ui/theme/default/posts.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_605bb512217c03_40671895',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'aa874c1b8f2972f6c780db32bed01cba567e973b' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/default/posts.tpl',
      1 => 1616622863,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_605bb512217c03_40671895 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_358640975605bb5122171f9_18374101', "content");
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['layouts_admin']->value));
}
/* {block "content"} */
class Block_358640975605bb5122171f9_18374101 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_358640975605bb5122171f9_18374101',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block "content"} */
}
