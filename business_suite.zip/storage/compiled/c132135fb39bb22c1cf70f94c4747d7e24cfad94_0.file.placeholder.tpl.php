<?php
/* Smarty version 3.1.39, created on 2021-07-13 03:09:36
  from '/Users/razib/Documents/valet/business-suite/ui/theme/default/placeholder.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60ec937073a490_06609857',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c132135fb39bb22c1cf70f94c4747d7e24cfad94' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/default/placeholder.tpl',
      1 => 1556267287,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../../../".((string)$_smarty_tpl->tpl_vars[\'placeholder\']->value).".tpl' => 1,
  ),
),false)) {
function content_60ec937073a490_06609857 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../../../".((string)$_smarty_tpl->tpl_vars['placeholder']->value).".tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}
