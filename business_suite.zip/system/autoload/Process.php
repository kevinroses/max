<?php
class Process extends Symfony\Component\Process\Process
{
}
