<?php
class ProcessFailedException extends
    Symfony\Component\Process\Exception\ProcessFailedException
{
}
