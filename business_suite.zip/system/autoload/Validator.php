<?php
class Validator extends \Rakit\Validation\Validator
{

}