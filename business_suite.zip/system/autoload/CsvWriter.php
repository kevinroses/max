<?php

use League\Csv\Writer;

class CsvWriter extends Writer
{
}
