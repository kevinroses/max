<?php
class Colors
{
    public static function random()
    {
    }

    public static function colorNames()
    {
        $colors = [
            'red',
            'pink',
            'purple',
            'deep_purple',
            'indigo',
            'blue',
            'light_blue',
            'cyan',
            'teal',
            'green',
            'light_green',
            'deep_orange',
            'brown',
            'grey',
            'blue_grey',
        ];

        return $colors;
    }
}
